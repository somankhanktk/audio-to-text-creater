document.addEventListener("DOMContentLoaded", function() {
    // Scroll Animation
    const elements = document.querySelectorAll(".animate-on-scroll");
    
    function scrollHandler() {
        elements.forEach((element) => {
            const position = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;

            if (position < windowHeight - 100) {
                element.classList.add("visible");
            }
        });
    }

    window.addEventListener("scroll", scrollHandler);
    scrollHandler();

    // Dark Mode Toggle
    const darkModeToggle = document.createElement("button");
    darkModeToggle.innerText = "Toggle Dark Mode";
    darkModeToggle.className = "btn btn-secondary m-3";
    document.body.prepend(darkModeToggle);

    darkModeToggle.addEventListener("click", function() {
        document.body.classList.toggle("dark-mode");
    });
});
